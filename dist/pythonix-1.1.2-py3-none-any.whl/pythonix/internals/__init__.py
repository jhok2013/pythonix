"""
Internal module for raw modules development. Raw code will go in files here and
will then be republished in the top layer.
"""
